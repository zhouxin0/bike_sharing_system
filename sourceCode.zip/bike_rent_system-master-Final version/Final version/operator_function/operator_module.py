# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 16:26:36 2019

@author: Song Yangyang & zhou xin
"""

import pymysql
import pandas as pd
from tkinter import ttk
from tkinter import *


# connect to database
connect = pymysql.connect(host="136.244.64.125", port=3306, user="songyangyang", password="root2019", db="bike_rent_system")
cursor = connect.cursor()


def operator_function():
    # track the location of all bikes : ID and postcode (by zhou xin)
    def track():
        region1 = op_txt1_1.get()
        station1 = op_txt1_2.get()
        if (region1 != '') and (station1 == ''):
            cursor.execute(
                'SELECT region,bike_station,post_code from bicycles where bicycles.region="%s"' % str(region1))
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode'])
            # .drop_duplicates()
            #  table1= tabel1.drop_duplicates()
            print(table1)
            # clear1(op_lst1)
            op_lst1.heading("1", text="region")  # 显示表头
            op_lst1.heading("2", text="bike_station")
            op_lst1.heading("3", text="postcode")
            op_lst1.heading("4", text="")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                op_lst1.insert("", i, text=i, values=tuple1)
                i += 1
        elif (region1 == '') and (station1 != ''):
            cursor.execute(
                'SELECT region,bike_station,post_code,bicycle_id from bicycles where bicycles.bike_station=%s' % int(
                    station1))  # bike_station
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode', 'bicyle_id', ])
            # clear1(op_lst1)
            op_lst1.heading("1", text="region")  # 显示表头
            op_lst1.heading("2", text="bike_station")
            op_lst1.heading("3", text="post_code")  # 显示表头
            op_lst1.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                op_lst1.insert("", i, text=i, values=tuple1)
                i += 1
        elif (region1 != '') and (station1 != ''):
            cursor.execute(
                'SELECT region,bike_station,post_code,bicycle_id from bicycles where bicycles.bike_station=%s' % (
                    int(station1)))
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode', 'bicyle_id', ])
            # clear1(op_lst1)
            op_lst1.heading("1", text="region")  # 显示表头
            op_lst1.heading("2", text="bike_station")
            op_lst1.heading("3", text="post_code")  # 显示表头
            op_lst1.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                if list1[0] == region1:
                    tuple1 = tuple(list1)
                    op_lst1.insert("", i, text=i, values=tuple1)
                    i += 1
        elif (region1 == '') and (station1 == ''):
            cursor.execute('SELECT region,bike_station,post_code,bicycle_id from bicycles')
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode', 'bicycle_id'])
            print(table1)
            # clear1(op_lst1)
            op_lst1.heading("1", text="region")  # 显示表头
            op_lst1.heading("2", text="bike_station")
            op_lst1.heading("3", text="post_code")  # 显示表头
            op_lst1.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                op_lst1.insert("", i, text=i, values=tuple1)
                i += 1

    # View the info of all broken bikes: ID and lateset postcode (by zhou xin)
    def view():
        region2 = op_txt2_1.get()
        station2 = op_txt2_2.get()
        if (region2 != '') and (station2 == ''):
            cursor.execute(
                'SELECT broken_status,bike_station,repaired_times,bicycle_id from bike_rent_system.bicycles where bicycles.broken_status= 1 and bicycles.region="%s"' % str(
                    region2))
            # INCOME > % s" % (1000)
            table1 = pd.DataFrame(cursor.fetchall(),
                                  columns=['broken_status', 'bike_station', 'postcode', 'bicycle_id'])
            #  table1= tabel1.drop_duplicates()
            print(table1)
            # clear1(op_lst1)
            op_lst2.heading("1", text="broken_status")  # 显示表头
            op_lst2.heading("2", text="bike_station")
            op_lst2.heading("3", text="repaired_times")
            op_lst2.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                op_lst2.insert("", i, text=i, values=tuple1)
                i += 1
        elif (region2 == '') and (station2 != ''):
            cursor.execute(
                'SELECT broken_status,bike_station,repaired_times,bicycle_id from bicycles where bicycles.broken_status= 1 and bicycles.bike_station=%s' % int(
                    station2))
            table1 = pd.DataFrame(cursor.fetchall(),
                                  columns=['broken_status', 'bike_station', 'postcode', 'bicycle_id'])
            # clear1(op_lst1)
            op_lst2.heading("1", text="broken_status")  # 显示表头
            op_lst2.heading("2", text="bike_station")
            op_lst2.heading("3", text="repaired_times")  # 显示表头
            op_lst2.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                op_lst2.insert("", i, text=i, values=tuple1)
                i += 1
        elif (region2 != '') and (station2 != ''):
            cursor.execute(
                'SELECT region,bike_station,repaired_times,bicycle_id from bicycles where bicycles.broken_status=1 and bicycles.bike_station=%s' % (
                    int(station2)))
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode', 'bike_id', ])
            # clear1(op_lst1)
            op_lst2.heading("1", text="region")  # 显示表头
            op_lst2.heading("2", text="bike_station")
            op_lst2.heading("3", text="repaired_times")  # 显示表头
            op_lst2.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                if list1[0] == region2:
                    tuple1 = tuple(list1)
                    op_lst2.insert("", i, text=i, values=tuple1)
                    i += 1
        elif (region2 == '') and (station2 == ''):
            cursor.execute(
                'SELECT broken_status,bike_station,repaired_times,bicycle_id from bicycles where bicycles.broken_status= 1 ')
            table1 = pd.DataFrame(cursor.fetchall(),
                                  columns=['broken_status', 'bike_station', 'postcode', 'bicycle_id'])
            print(table1)
            # clear1(op_lst1)
            op_lst2.heading("1", text="broken_status")  # 显示表头
            op_lst2.heading("2", text="bike_station")
            op_lst2.heading("3", text="repaired_times")  # 显示表头
            op_lst2.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                op_lst2.insert("", i, text=i, values=tuple1)
                i += 1

    # change broken status from 1 to 0(by SYY)
    def repair():
        bikeid = str(op_txt1.get())
        cursor = connect.cursor()

        sql1 = "SELECT repaired_times FROM bicycles WHERE bicycles.bicycle_id = %s"
        cursor.execute(sql1, bikeid)
        results = cursor.fetchall()
        for row in results:
            r = row[0]

        updated_repair_times = r + 1
        sql2 = "UPDATE bicycles SET broken_status = '0',repaired_times = %s WHERE bicycles.bicycle_id = %s"
        cursor.execute(sql2, (updated_repair_times, bikeid))
        connect.commit()

    def scrap():
        bikeid = str(op_txt1.get())
        cursor = connect.cursor()

        sql1 = "UPDATE bicycles SET broken_status ='2' WHERE bicycle_id = %s"
        cursor.execute(sql1, bikeid)
        connect.commit()

    # change bikestation  (by SYY)
    def move():
        bikeid = str(op_txt2.get())
        new_region = str(op_txt3.get())
        new_sta = int(op_txt4.get())
        cursor = connect.cursor()
        sql = "UPDATE bicycles SET region=%s,bike_station = %s WHERE bicycles.bicycle_id = %s"
        cursor.execute(sql, (new_region, new_sta, bikeid))
        connect.commit()

        # 移动车时生成一个订单号加入到price表里
        oder_number = cursor.execute('SELECT order_number From price')
        op_order_number1 = oder_number + 1
        op_order_number2 = str(op_order_number1).zfill(8)
        print(op_order_number2)
        null = 'null'
        cursor.execute(
            'INSERT into price(order_number,start_time,end_time,period_of_use,customer,amount,bicycle_id,start_bike_station,end_bike_station)values(%s,%s,%s,%f,%s,%f,%s,%s,%s)' % (
            op_order_number2, null, null, 0, 0, 0, bikeid, 0, new_sta))
        connect.commit()

    def delButton():
        x = op_lst1.get_children()
        for item in x:
            op_lst1.delete(item)
        x = op_lst2.get_children()
        for item in x:
            op_lst2.delete(item)

    # GUI(by SYY)

    window_operator = Tk()
    window_operator.title("Operator system")
    window_operator.geometry("600x800")

    # 1.Track
    # click button 1 to show the location information of all bikes in listbox 1
    op_lb1_1 = Label(window_operator, text="Track", background="light grey")
    op_lb1_1.place(x=50, y=10)

    # Enter region
    op_lb1_2 = Label(window_operator, text="Region")
    op_lb1_2.place(x=50, y=30)

    op_txt1_1 = Entry(window_operator, text="")
    op_txt1_1.place(x=150, y=30, width=200, height=25)
    op_txt1_1["justify"] = "left"
    op_txt1_1.focus()

    # Enter bikestation
    op_lb1_3 = Label(window_operator, text="Bike station")
    op_lb1_3.place(x=50, y=60)

    op_txt1_2 = Entry(window_operator, text="")
    op_txt1_2.place(x=150, y=60, width=200, height=25)
    op_txt1_2["justify"] = "left"
    op_txt1_2.focus()

    op_bt1_1 = Button(window_operator, text="Track all bikes", command=track)
    op_bt1_1.place(x=400, y=30, width=150, height=25)

    op_bt1_2 = Button(window_operator, text="Clear", command=delButton)
    op_bt1_2.place(x=400, y=60, width=150, height=25)

    # op_ls1=Listbox()
    # op_ls1.place(x=50,y=90,width=500,height=150)

    op_lst1 = ttk.Treeview(window_operator, show="headings")
    op_lst1["columns"] = ('1', '2', '3', '4')
    op_lst1.column('1', width=100)  # 表示列,不显示
    op_lst1.column('2', width=100)
    op_lst1.column('3', width=100)
    op_lst1.column('4', width=100)
    op_lst1.place(x=50, y=90, width=500, height=150)

    # 2.Repair
    # click button 2 to show the information of all broken bikes in listbox 2
    op_lb2 = Label(window_operator, text="Repair", background="light grey")
    op_lb2.place(x=50, y=290)

    # Enter region
    op_lb2_2 = Label(window_operator, text="Region")
    op_lb2_2.place(x=50, y=320)

    op_txt2_1 = Entry(window_operator, text="")
    op_txt2_1.place(x=150, y=320, width=200, height=25)
    op_txt2_1["justify"] = "left"
    op_txt2_1.focus()

    # Enter bikestation
    op_lb2_3 = Label(window_operator, text="Bike station")
    op_lb2_3.place(x=50, y=350)

    op_txt2_2 = Entry(window_operator, text="")
    op_txt2_2.place(x=150, y=350, width=200, height=25)
    op_txt2_2["justify"] = "left"
    op_txt2_2.focus()

    op_bt2_1 = Button(window_operator, text="Track broken bikes", command=view)
    op_bt2_1.place(x=400, y=320, width=150, height=25)

    op_bt2_2 = Button(window_operator, text="Clear", command=delButton)
    op_bt2_2.place(x=400, y=350, width=150, height=25)

    # op_ls2=Listbox()
    # op_ls2.place(x=50,y=380,width=500,height=150)

    op_lst2 = ttk.Treeview(window_operator, show="headings")
    op_lst2["columns"] = ('1', '2', '3', '4')
    op_lst2.column('1', width=100)  # 表示列,不显示
    op_lst2.column('2', width=100)
    op_lst2.column('3', width=100)
    op_lst2.column('4', width=100)
    op_lst2.place(x=50, y=380, width=500, height=150)

    # enter broken bike ID in textbox1 and click button3 to change bike status
    op_lb3 = Label(window_operator, text="Enter broken bike ID:")
    op_lb3.place(x=50, y=560, width=250, height=25)

    op_txt1 = Entry(window_operator, text="")
    op_txt1.place(x=300, y=560, width=250, height=25)
    op_txt1["justify"] = "left"
    op_txt1.focus()

    op_bt3 = Button(window_operator, text="Repair finished", command=repair)
    op_bt3.place(x=50, y=590, width=250, height=25)

    op_bt3_2 = Button(window_operator, text="Scrape the bike", command=scrap)
    op_bt3_2.place(x=300, y=590, width=250, height=25)

    # 3.Move
    # enter bike ID in textbox2, new region in textbox3,new bikestation in textbox4 and click button4 to move bikes
    op_lb4 = Label(window_operator, text="Move", background="light grey")
    op_lb4.place(x=50, y=630)

    op_lb5 = Label(window_operator, text="Enter bike ID:")
    op_lb5.place(x=50, y=660, width=250, height=25)

    op_txt2 = Entry(window_operator, text="")
    op_txt2.place(x=300, y=660, width=250, height=25)
    op_txt2["justify"] = "left"
    op_txt2.focus()

    op_lb6 = Label(window_operator, text="Enter new region:")
    op_lb6.place(x=50, y=690, width=250, height=25)

    op_txt3 = Entry(window_operator, text="")
    op_txt3.place(x=300, y=690, width=250, height=25)
    op_txt3["justify"] = "left"
    op_txt3.focus()

    op_lb7 = Label(window_operator, text="Enter new bikestation:")
    op_lb7.place(x=50, y=720, width=250, height=25)

    op_txt4 = Entry(window_operator, text="")
    op_txt4.place(x=300, y=720, width=250, height=25)
    op_txt4["justify"] = "left"
    op_txt4.focus()

    op_bt4 = Button(window_operator, text="Move bikes", command=move)
    op_bt4.place(x=50, y=750, width=500, height=25)

    window_operator.mainloop()
