# -*- coding: utf-8 -*-
# @Time    : 2019/10/11 8:00 下午
# @Author  : Lucio Wang
# @FileName: database_connection.py
# @Software: PyCharm
# @Github    ：wly1996

import pymysql


def connection():

    connect = pymysql.connect(
        host="136.244.64.125",
        port=3306,
        user="root",
        passwd="root2019",
        db="bike_rent_system"
    )

    return connect
