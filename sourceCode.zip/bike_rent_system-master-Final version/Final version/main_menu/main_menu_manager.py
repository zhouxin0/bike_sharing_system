# -*- coding: utf-8 -*-apt-
# @Time    : 2019/10/15 1:02 上午
# @Author  : Lucio Wang
# @FileName: main_menu_manager.py
# @Software: PyCharm
# @Github    ：wly1996

from tkinter import *
from tkinter import messagebox
from manager.manager_module import manager_operation
import pymysql

connect = pymysql.connect(host="136.244.64.125", port=3306, user="songyangyang", password="root2019", db="bike_rent_system")
cursor = connect.cursor()


def manager_login():

    def manager_verify():

        sql1 = 'select password from staff where account_number = %s'
        sql2 = 'select count(*) from staff where account_number = %s'

        manager_account_number = textbox1.get()
        manager_account_number = str(manager_account_number)

        manager_password = textbox2.get()
        manager_password = str(manager_password)

        cursor.execute(sql1, manager_account_number)
        result1 = cursor.fetchall()

        cursor.execute(sql2, manager_account_number)
        result2 = cursor.fetchall()

        for (result2,) in result2:
            if result2 == 1:
                for (result1,) in result1:
                    if manager_password == result1:
                        messagebox.showinfo('Message', 'Success')
                        manager_operation()
                    else:
                        messagebox.showerror('Error', 'Error password!')
            else:
                messagebox.showerror('Error', 'Account not exist.')

    window_manager_login = Tk()
    window_manager_login.title("Manager Login")
    window_manager_login.geometry('400x200')

    label1 = Label(window_manager_login, text="Account number:")
    label1.place(x=30, y=20)
    textbox1 = Entry(window_manager_login, text="")
    textbox1.place(x=150, y=20, width=200, height=25)

    label2 = Label(window_manager_login, text="Password:")
    label2.place(x=30, y=50)
    textbox2 = Entry(window_manager_login, text="", show="*")
    textbox2.place(x=150, y=50, width=200, height=25)

    staff_login_button1 = Button(window_manager_login, text="Login", command=manager_verify)
    staff_login_button1.place(x=150, y=80, width=100, height=25)

    staff_login_button2 = Button(window_manager_login, text="Return", command=window_manager_login.destroy)
    staff_login_button2.place(x=250, y=80, width=100, height=25)

    window_manager_login.mainloop()
    connect.close()

