# -*- coding: utf-8 -*-
# @Time    : 2019/10/15 1:06 上午
# @Author  : Lucio Wang
# @FileName: main_menu_customer.py
# @Software: PyCharm
# @Github    ：wly1996

from tkinter import *
from tkinter import messagebox
from customer.GUI import customer_operation
import pymysql

connect = pymysql.connect(host="136.244.64.125", port=3306, user="songyangyang", password="root2019", db="bike_rent_system")
cursor = connect.cursor()

customer_account_number = 0

def customer_login():

    def customer_verify():

        sql1 = 'select password from customers where account_number = %s'
        sql2 = 'select count(*) from customers where account_number = %s'

        global customer_account_number
        customer_account_number = textbox1.get()
        customer_account_number = str(customer_account_number)

        customer_password = textbox2.get()
        customer_password = str(customer_password)

        cursor.execute(sql1, customer_account_number)
        result1 = cursor.fetchall()

        cursor.execute(sql2, customer_account_number)
        result2 = cursor.fetchall()

        for (result2,) in result2:
            if result2 == 1:
                for (result1,) in result1:
                    if customer_password == result1:
                        messagebox.showinfo('Message', 'Success')
                        customer_operation()
                    else:
                        messagebox.showerror('Error', 'Error password!\nPlease try again.')
            else:
                messagebox.showerror('Error', 'Account not exist.')

    window_customer_login = Tk()
    window_customer_login.title("Login")
    window_customer_login.geometry('400x200')

    label1 = Label(window_customer_login, text="Account number:")
    label1.place(x=30, y=20)
    textbox1 = Entry(window_customer_login, text="")
    textbox1.place(x=150, y=20, width=200, height=25)
    # textbox1.focus()

    label2 = Label(window_customer_login, text="Password:")
    label2.place(x=30, y=50)
    textbox2 = Entry(window_customer_login, text="", show="*")
    textbox2.place(x=150, y=50, width=200, height=25)
    # textbox2.focus()

    customer_login_button1 = Button(window_customer_login, text="Sign in", command=customer_verify)
    customer_login_button1.place(x=150, y=80, width=100, height=25)

    customer_login_button2 = Button(window_customer_login, text="Sign up", command=customer_signup)
    customer_login_button2.place(x=250, y=80, width=100, height=25)

    window_customer_login.mainloop()


def customer_signup():

    def sign():
        sql1 = 'select count(*) from customers where account_number = %s'
        sql2 = 'insert into customers(account_number, password, first_name, family_name, tel, email) values(%s,%s,%s,%s,%s,%s)'

        account_number = signup_textbox1.get()
        password = signup_textbox2.get()
        first_name = signup_textbox3.get()
        family_name = signup_textbox4.get()
        tel = signup_textbox5.get()
        email = signup_textbox6.get()

        account_number = str(account_number)
        password = str(password)
        first_name = str(first_name)
        family_name = str(family_name)
        tel = str(tel)
        email = str(email)

        val = (account_number, password, first_name, family_name, tel, email)

        cursor.execute(sql1, account_number)
        result1 = cursor.fetchall()

        for (result1,) in result1:
            if result1 == 1:
                messagebox.showerror('Error', 'Account number already exists.')
            else:
                cursor.execute(sql2, val)
                messagebox.showinfo("Message", "Success")
                connect.commit()

    window_customer_signup = Tk()
    window_customer_signup.geometry("400x200")
    window_customer_signup.title("Sign up")

    signup_label1 = Label(window_customer_signup, text="Account number:")
    signup_label1.place(x=30, y=5)
    signup_textbox1 = Entry(window_customer_signup, text="")
    signup_textbox1.place(x=150, y=5, width=200, height=25)

    signup_label2 = Label(window_customer_signup, text="Password:")
    signup_label2.place(x=30, y=30)
    signup_textbox2 = Entry(window_customer_signup, text="", show="*")
    signup_textbox2.place(x=150, y=30, width=200, height=25)

    signup_label3 = Label(window_customer_signup, text="First name:")
    signup_label3.place(x=30, y=55)
    signup_textbox3 = Entry(window_customer_signup, text="")
    signup_textbox3.place(x=150, y=55, width=200, height=25)

    signup_label4 = Label(window_customer_signup, text="Family name:")
    signup_label4.place(x=30, y=80)
    signup_textbox4 = Entry(window_customer_signup, text="")
    signup_textbox4.place(x=150, y=80, width=200, height=25)

    signup_label5 = Label(window_customer_signup, text="Telephone:")
    signup_label5.place(x=30, y=105)
    signup_textbox5 = Entry(window_customer_signup, text="")
    signup_textbox5.place(x=150, y=105, width=200, height=25)

    signup_label6 = Label(window_customer_signup, text="E-mail:")
    signup_label6.place(x=30, y=130)
    signup_textbox6 = Entry(window_customer_signup, text="")
    signup_textbox6.place(x=150, y=130, width=200, height=25)

    signup_button1 = Button(window_customer_signup, text="Sign in", command=sign)
    signup_button1.place(x=150, y=155, width=100, height=25)

    signup_button2 = Button(window_customer_signup, text="Return", command=window_customer_signup.destroy)
    signup_button2.place(x=250, y=155, width=100, height=25)

    window_customer_signup.mainloop()
    connect.close()



