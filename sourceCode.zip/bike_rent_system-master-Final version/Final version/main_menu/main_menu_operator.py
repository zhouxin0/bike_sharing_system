# -*- coding: utf-8 -*-
# @Time    : 2019/10/15 1:04 上午
# @Author  : Lucio Wang
# @FileName: main_menu_operator.py
# @Software: PyCharm
# @Github    ：wly1996

from tkinter import *
from tkinter import messagebox
import pymysql
from operator_function.operator_module import operator_function

connect = pymysql.connect(host="136.244.64.125", port=3306, user="songyangyang", password="root2019", db="bike_rent_system")
cursor = connect.cursor()


def operator_login():

    def operator_verify():

        sql1 = 'select password from staff where account_number = %s'
        sql2 = 'select count(*) from staff where account_number = %s'

        operator_account_number = textbox1.get()
        operator_account_number = str(operator_account_number)

        operator_password = textbox2.get()
        operator_password = str(operator_password)

        cursor.execute(sql1, operator_account_number)
        result1 = cursor.fetchall()

        cursor.execute(sql2, operator_account_number)
        result2 = cursor.fetchall()

        for (result2,) in result2:
            if result2 == 1:
                for (result1,) in result1:
                    if operator_password == result1:
                        messagebox.showinfo('Message', 'Success')
                        operator_function()
                    else:
                        messagebox.showerror('Error', 'Error password!')
            else:
                messagebox.showerror('Error', 'Account not exist.')

    window_operator_login = Tk()
    window_operator_login.title("Operator Login")
    window_operator_login.geometry('400x200')

    label1 = Label(window_operator_login, text="Account number:")
    label1.place(x=30, y=20)
    textbox1 = Entry(window_operator_login, text="")
    textbox1.place(x=150, y=20, width=200, height=25)

    label2 = Label(window_operator_login, text="Password:")
    label2.place(x=30, y=50)
    textbox2 = Entry(window_operator_login, text="", show="*")
    textbox2.place(x=150, y=50, width=200, height=25)

    staff_login_button1 = Button(window_operator_login, text="Login", command=operator_verify)
    staff_login_button1.place(x=150, y=80, width=100, height=25)

    staff_login_button2 = Button(window_operator_login, text="Return", command=window_operator_login.destroy)
    staff_login_button2.place(x=250, y=80, width=100, height=25)

    window_operator_login.mainloop()
    connect.close()
