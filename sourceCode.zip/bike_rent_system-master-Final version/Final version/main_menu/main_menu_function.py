# -*- coding: utf-8 -*-
# @Time    : 2019/10/15 12:20 上午
# @Author  : Lucio Wang
# @FileName: main_menu_function.py
# @Software: PyCharm
# @Github    ：wly1996

from tkinter import *
from main_menu.main_menu_manager import manager_login
from main_menu.main_menu_operator import operator_login
from main_menu.main_menu_customer import customer_login


main_menu_window = Tk()
main_menu_window.title("Bike Share System")
main_menu_window.geometry("400x200")

main_menu_button1 = Button(main_menu_window, text="Manager", height=5, width=10, command=manager_login)
main_menu_button1.place(x=50, y=50)

main_menu_button2 = Button(main_menu_window, text="Operator", height=5, width=10, command=operator_login)
main_menu_button2.place(x=150, y=50)

main_menu_button3 = Button(main_menu_window, text="Customer", height=5, width=10, command=customer_login)
main_menu_button3.place(x=250, y=50)

main_menu_window.mainloop()
