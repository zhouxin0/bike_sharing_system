from tkinter import *
import pandas as pd
import pymysql
import matplotlib.pyplot as plt
import datetime
import numpy as np

# Connecting to MySQL Server

connect = pymysql.connect(host="136.244.64.125", port=3306, user="songyangyang", password="root2019", db="bike_rent_system")
cursor = connect.cursor()


# Performing 2 queries in order to get price and bicycles tables from our database

df_price = pd.read_sql('SELECT * FROM price', con=connect)
df = pd.read_sql('SELECT *  FROM bicycles', con=connect)

# Function for plotting the distribution of the years that the bicyles have been bought


def manager_operation():
    def bought_time():

        sum = np.array([0, 0])  # initializing an empty array to sum the number of bikes for each year

        for index, i in df.iterrows():
            bought = datetime.datetime.strptime(str(df["bought_time"].iloc[index]), "%Y-%m-%d")  # parsing datetime data

            if bought.year == 2018:
                sum[0] = sum[0] + 1
            elif bought.year == 2019:
                sum[1] = sum[1] + 1

        years = ["2018", "2019"]

        # Making a pie plot

        plt.title('Bicycles Bought Year')
        plt.pie(sum, labels=years, shadow=True, autopct='%1.1f%%', startangle=180)
        plt.axis('equal')
        plt.show()

    # Function for plotting the number of broken bikes in each station

    def broken_bikes():

        brokens = np.zeros(30)

        for index, i in df.iterrows():

            for x in range(len(df['bike_station'].unique())):

                if x == df["bike_station"].iloc[index]:
                    brokens[x] = brokens[x] + df["broken_status"].iloc[index]

        stations = df["bike_station"].unique()

        # function to sort the stations from 1 to 30

        def selection_sort(x):
            for i in range(len(x)):
                swap = i + np.argmin(x[i:])
                (x[i], x[swap]) = (x[swap], x[i])
            return x

        station = selection_sort(stations)

        plt.bar(station, brokens)
        plt.xticks(station, color='black')
        plt.yticks(color='black')
        plt.legend(['Broken bikes'], loc='best')
        plt.ylabel("Number of broken bikes")
        plt.xlabel("Station number")
        plt.show()
        # print(brokens) # print the 30-array with the broken bikes

    # Function to plot the profit of each month

    def monthly_profit():

        profit = np.zeros(12)  # initializing an empty array of 12 values

        for index, i in df_price.iterrows():
            date = datetime.datetime.strptime(str(df_price["start_time"].iloc[index]),
                                              "%Y-%m-%d %H:%M:%S")  # parsing timestamp data

            # Sum the amount for each month and assigning it to the relevant month position
            if date.month == 1:
                profit[0] = profit[0] + int(df_price["amount"][index])
            elif date.month == 2:
                profit[1] = profit[1] + int(df_price["amount"][index])
            elif date.month == 3:
                profit[2] = profit[2] + int(df_price["amount"][index])
            elif date.month == 4:
                profit[3] = profit[3] + int(df_price["amount"][index])
            elif date.month == 5:
                profit[4] = profit[4] + int(df_price["amount"][index])
            elif date.month == 6:
                profit[5] = profit[5] + int(df_price["amount"][index])
            elif date.month == 7:
                profit[6] = profit[6] + int(df_price["amount"][index])
            elif date.month == 8:
                profit[7] = profit[7] + int(df_price["amount"][index])
            elif date.month == 9:
                profit[8] = profit[8] + int(df_price["amount"][index])
            elif date.month == 10:
                profit[9] = profit[9] + int(df_price["amount"][index])
            elif date.month == 11:
                profit[10] = profit[10] + int(df_price["amount"][index])
            elif date.month == 12:
                profit[11] = profit[11] + int(df_price["amount"][index])

        months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
                  "November", "December"]

        plt.plot(profit, color="blue", ls="--", marker="o", ms=6, label="profit")
        plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
        plt.xticks(list(range(12)), months, rotation="vertical")
        plt.xlabel("Months")
        plt.ylabel("Amount of Money")
        plt.show()

    # Function for plotting the number of bikes in each region

    def bike_regions():

        labels = df['region'].unique()
        values = df['region'].value_counts()
        plt.title('Percentage Bikes/Region')
        plt.pie(values, labels=labels, shadow=True, autopct='%1.1f%%', startangle=180)
        plt.axis('equal')
        plt.show()

    # Function for pltting the distribution of bikes in stations

    def bike_stations():

        df['bike_station'].value_counts().plot(kind='bar')
        plt.xticks(color='black')
        plt.yticks(color='black')
        plt.xlabel("Station Number")
        plt.ylabel("Number of Bikes")
        plt.legend(['No bikes/station'], loc='best')
        plt.show()

    # Function to quit manager menu

    def close_window():
        window_manager.quit()

    # Manager GUI

    window_manager = Tk()
    window_manager.title("Manager Menu")
    window_manager.geometry('350x350')

    l = Label(window_manager, text="plot Bicycles/Region", font=("Times", 14))
    l.pack(expand=True)

    b = Button(window_manager, text="Bicycle/Region", bg="blue", font=("Times", 14), command=bike_regions)
    b.pack(expand=True)

    l1 = Label(window_manager, text="plot Profit/Month", font=("Times", 14))
    l1.pack(expand=True)

    b1 = Button(window_manager, text="Profit/Month", bg="blue", font=("Times", 14), command=monthly_profit)
    b1.pack(expand=True)

    l2 = Label(window_manager, text="plot Bicycles/Station", font=("Times", 14))
    l2.pack(expand=True)

    b2 = Button(window_manager, text="Bicycles/Station", bg="blue", font=("Times", 14), command=bike_stations)
    b2.pack(expand=True)

    l3 = Label(window_manager, text="plot Bicycles Bought Year", font=("Times", 14))
    l3.pack(expand=True)

    b3 = Button(window_manager, text="Bought Year", bg="blue", font=("Times", 14), command=bought_time)
    b3.pack(expand=True)

    l4 = Label(window_manager, text="plot Broken Bikes/Station", font=("Times", 14))
    l4.pack(expand=True)

    b4 = Button(window_manager, text="Broken Bikes/Station", bg="blue", font=("Times", 14), command=broken_bikes)
    b4.pack(expand=True)

    l5 = Label(window_manager, text="Quit Manager Menu", font=("Times", 14))
    l5.pack(expand=True)

    b5 = Button(window_manager, text="Quit", bg="blue", font=("Times", 14), command=close_window)
    b5.pack(expand=True)

    window_manager.mainloop()
    connect.close()
