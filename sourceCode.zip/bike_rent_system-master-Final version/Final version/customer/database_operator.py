import pymysql


def get_conn():
    conn = pymysql.connect(
        host="136.244.64.125",
        port=3306,
        user="root",
        passwd="root2019",
        db="bike_rent_system"
    )
    return conn


def get_cursor(conn):
    cursor = conn.cursor()
    return cursor


def close_db(cursor, conn):
    cursor.close()
    conn.close()
