import pymysql
from datetime import datetime
from customer import database_operator


def show_bike_station():
    # get postcode from city location table and save name into postcode_list
    conn = database_operator.get_conn()
    cursor = database_operator.get_cursor(conn)
    region_list = []
    bikestation_list = []
    postcode_list=[]
    full_list = []
    sql = "select * from city_location"
    cursor.execute(sql)
    results = cursor.fetchall()
    for row in results:
        region_list.append(row[0])
        bikestation_list.append(row[1])
        postcode_list.append(row[2])
    for i in range(len(postcode_list)):
        str ="Region: "+ region_list[i]+"    "+ "Bike_station: "+bikestation_list[i] +"    "+"Post_code: " +postcode_list[i]
        full_list.append(str)
    database_operator.close_db(cursor,conn)
    return full_list


def sel_bikestation(bike_station, order_number):
    conn = database_operator.get_conn()
    cursor = database_operator.get_cursor(conn)
    print("order_number")
    print(order_number)
    sql = "select bicycle_id from price where order_number = %s"
    cursor.execute(sql, order_number)
    bicycle_number_result = cursor.fetchone()
    bicycle_number = bicycle_number_result[0]
    print("bicycle_num")
    print(bicycle_number)
    sql_getloc_info = "select * from city_location where bike_station = %s"
    cursor.execute(sql_getloc_info, bike_station)
    loc_info = cursor.fetchone()
    print(loc_info)
    end_region = loc_info[0]
    end_station = loc_info[1]
    end_postcode = loc_info[2]

    sql_region_bicycles = "update bicycles set region = '%s',bike_station = %s,post_code='%s' where bicycle_id = '%s'"%(end_region,end_station,end_postcode,bicycle_number)
    print(sql_region_bicycles)
    cursor.execute(sql_region_bicycles)
    conn.commit()
    sql_region_price = "update price set end_bike_station = %s where order_number = %s"%(end_station,order_number)
    cursor.execute(sql_region_price)
    conn.commit()
    database_operator.close_db(cursor,conn)

def cal_amount(oder_number):
    # determin start time
    start_time = ''
    end_time = ''
    conn = database_operator.get_conn()
    cursor = database_operator.get_cursor(conn)
    sql = "select start_time,end_time from price where order_number = %s"%oder_number
    cursor.execute(sql)
    results = cursor.fetchall()
    for row in results:
        start_time = str(row[0])
        end_time = str(row[1])
    start_time_date = datetime.strptime(start_time,'%Y-%m-%d %H:%M:%S')
    end_time_date = datetime.strptime(end_time,'%Y-%m-%d %H:%M:%S')
    delta = ((end_time_date-start_time_date).seconds)/60*60
    if delta < 1:
        delta = 1
        amount = 1
    else:
        amount = delta * 0.95
    sql_amount = "update price set amount = %f,period_of_use = %d where order_number = %s"%(amount,delta,oder_number)
    cursor.execute(sql_amount)
    conn.commit()
    database_operator.close_db(cursor,conn)
    return amount


def show_order(order_number):
    order_list = []
    conn = database_operator.get_conn()
    cursor = database_operator.get_cursor(conn)
    # sql = "select * from price where order_number = %s"%order_number
    sql = "select * from price where order_number = %s"%order_number
    cursor.execute(sql)
    results = cursor.fetchall()
    for row in results:
        order_list = row
    database_operator.close_db(cursor,conn)
    return order_list


def return_bike(order_number):
    conn = database_operator.get_conn()
    cursor = database_operator.get_cursor(conn)
    print("return order number")
    print(order_number)
    sql_custumer_bicycle_id = "select customer,bicycle_id from price where order_number = %s"%order_number
    cursor.execute(sql_custumer_bicycle_id)
    results = cursor.fetchone()
    customer = results[0]
    bicycle_id = results[1]
    print("return bike id ")
    print(bicycle_id)
    sql_used_times = "select used_times from bicycles where bicycle_id = %s"
    cursor.execute(sql_used_times, bicycle_id)
    used_times_result = cursor.fetchone()
    print("used_times_results")
    print(used_times_result)
    used_times = used_times_result[0]
    print(used_times)
    used_times = used_times+1
    # update endTime
    endtime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql_endtime = "update price set end_time = '%s' where order_number = %s"%(endtime,order_number)
    cursor.execute(sql_endtime)
    conn.commit()
    # update bicycle status
    sql_rent_status = "update bicycles set rent_status = 0,the_last_user = %s,the_last_used_time = '%s',used_times = %d where bicycle_id = %s"%(customer,endtime,used_times, bicycle_id)
    cursor.execute(sql_rent_status)
    conn.commit()
    database_operator.close_db(cursor,conn)


def pay_order(order_number):
    # determin amount and bicyle_number by ordernumber
    amount = cal_amount(order_number)
    conn = database_operator.get_conn()
    cursor = database_operator.get_cursor(conn)
    sql_custumer = "select customer from price where order_number = %s"%order_number
    cursor.execute(sql_custumer)
    customer_result = cursor.fetchone()
    customer=customer_result[0]
    sql_show_balance = "select balance from customers where account_number = %s"%customer
    cursor.execute(sql_show_balance)
    balance_results = cursor.fetchone()
    balance = balance_results[0]
    if balance < amount:
        return False
    else:
        balance = balance - amount
        sql_balance = "update customers set balance = %s where account_number = %s"%(balance,customer)
        cursor.execute(sql_balance)
        conn.commit()
        # orderStatus(
        # sql_orderstatus = "update price set order_status = 1 where order_number = %s"%order_number
        # cursor.execute(sql_orderstatus)
        # conn.commit()

        database_operator.close_db(cursor,conn)
        return True

