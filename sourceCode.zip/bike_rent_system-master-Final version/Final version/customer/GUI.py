import pymysql
import pandas as pd
from customer import payAmount
import tkinter as tk
import tkinter.messagebox
from tkinter import *
from tkinter import ttk
import main_menu.main_menu_customer
import random
import datetime as dt

conn = pymysql.connect(host='136.244.64.125', port=3306, user='zhouyuehang', password='root2019', db="bike_rent_system",charset='UTF8MB4')
cursor = conn.cursor()
cst_lst1 = ''
cst_lst3 = ''
order_number2 = 0


def customer_operation():

    def clear1(tree):
        x = tree.get_children()
        for item in x:
            tree.delete(item)

    def clear3(tree):
        x = tree.get_children()
        for item in x:
            tree.delete(item)

    # display the related bike station when customer enter a region，or display the bike searched by customer
    def search1():
        region1 = cst_regiontext.get()
        bike_id = cst_BikeIdText.get()
        if (region1 != '') and (bike_id == ''):
            cursor.execute(
                'SELECT region,bike_station,post_code from bicycles where bicycles.region="%s"' % str(region1))
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode']).drop_duplicates()
            #  table1= tabel1.drop_duplicates()
            print(table1)
            clear1(cst_lst1)
            cst_lst1.heading("1", text="region")  # show table header
            cst_lst1.heading("2", text="bike_station")
            cst_lst1.heading("3", text="postcode")
            cst_lst1.heading("4", text="")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                cst_lst1.insert("", i, text=i, values=tuple1)
                i += 1
        elif (region1 == '') and (bike_id != ''):
            cursor.execute('SELECT bicycle_id,bike_station from bicycles where bicycles.bicycle_id=%s' % int(bike_id))
            table1 = pd.DataFrame(cursor.fetchall(), columns=['bike_id', 'bike_station'])
            clear1(cst_lst1)
            cst_lst1.heading("1", text="bicycle_id")  # show table header
            cst_lst1.heading("2", text="bike_station")
            cst_lst1.heading("3", text="")  # show table header
            cst_lst1.heading("4", text="")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                cst_lst1.insert("", i, text=i, values=tuple1)
                i += 1
        elif (region1 != '') and (bike_id != ''):
            cursor.execute(
                'SELECT region,bike_station,post_code,bicycle_id from bicycles where bicycles.bicycle_id=%s' % (
                    int(bike_id)))
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode', 'bike_id', ])
            clear1(cst_lst1)
            cst_lst1.heading("1", text="region")  # show table header
            cst_lst1.heading("2", text="bike_station")
            cst_lst1.heading("3", text="post_code")  # show table header
            cst_lst1.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                if list1[0] == region1:
                    tuple1 = tuple(list1)
                    cst_lst1.insert("", i, text=i, values=tuple1)
                    i += 1
        elif (region1 == '') and (bike_id == ''):
            cursor.execute('SELECT region,bike_station,post_code,bicycle_id from bicycles')
            table1 = pd.DataFrame(cursor.fetchall(), columns=['region', 'bike_station', 'postcode', 'bicycle_id'])
            print(table1)
            clear1(cst_lst1)
            cst_lst1.heading("1", text="region")  # show table header
            cst_lst1.heading("2", text="bike_station")
            cst_lst1.heading("3", text="post_code")  # show table header
            cst_lst1.heading("4", text="bicycle_id")
            i = 0
            for indexs in table1.index:
                list1 = table1.loc[indexs].values
                tuple1 = tuple(list1)
                cst_lst1.insert("", i, text=i, values=tuple1)
                i += 1

    # clear the content of region text and bike ID
    def clear():  # done
        cst_regiontext.delete(0, END)
        cst_BikeIdText.delete(0, END)

    # rent a bike--change the status of a bike
    def rent(rentStatus=0, brokenStatus=0):
        customer=main_menu.main_menu_customer.customer_account_number
        bike_id = str(cst_BikeIdText.get())
        global order_number2
        print(bike_id)
        if int(rentStatus) == 0 and int(brokenStatus) == 0:
            cursor.execute('SELECT rent_status FROM bicycles WHERE bicycles.bicycle_id=%s' % bike_id)
            rentStatus = str(cursor.fetchall()[0])[1]
            print(rentStatus)
            if (rentStatus != 0):
                cursor.execute('SELECT order_number FROM price WHERE bicycle_id=%s' % bike_id)
                result = cursor.fetchone()
                order_number2 = result[0]
                print("order_number2 exist")
                print(order_number2)
            brokenStatus = cursor.execute('SELECT broken_status FROM bicycles WHERE bicycles.bicycle_id=%s' % bike_id)
            brokenStatus = str(cursor.fetchall()[0])[1]
            print(brokenStatus)
            while int(rentStatus) == 0 and int(brokenStatus) == 0:
                # run a new order number
                result = cursor.execute('SELECT order_number From price')
                print(result)
                order_number1 = result + 1
                print(order_number1)
                order_number2 = str(order_number1).zfill(8)
                print("2222")
                print(order_number2)
                print("2222")
                print("rent order_number")
                print(order_number2)
                bike_id = str(bike_id).zfill(6)
                print("3333")
                print(bike_id)
                print("3333")
                startbikestation = cursor.execute('SELECT bike_station FROM bicycles WHERE bicycles.bicycle_id=%s' % bike_id)
                print("startbikestation")
                print(startbikestation)
                null = 'null'
                cursor.execute("""INSERT into price(order_number,start_time,end_time,period_of_use,customer,amount,bicycle_id,start_bike_station,end_bike_station)values('%s',%s,%s,%f,'%s',%f,'%s',%s,%s)""" % (order_number2, null, null, 0, customer, 0, bike_id, startbikestation, 0))
                conn.commit()
                # update bike status
                cursor.execute('UPDATE bicycles SET rent_status="1" WHERE bicycles.bicycle_id=%s' % bike_id)
                rentStatus = 1
                conn.commit()

            tkinter.messagebox.showinfo("Bike Share System", "Success")
        else:
            tkinter.messagebox.showinfo("Bike Share System", "Failure")


    # search the bike and display the imformation about this bike(including the bike station and bike ID)
    def search3():
        bike_id = cst_BikeIdText3.get()
        cursor.execute('SELECT bicycle_id,bike_station from bicycles where bicycles.bicycle_id=%s' % int(bike_id))
        table3 = pd.DataFrame(cursor.fetchall(), columns=['bike_id', 'bike_station'])
        clear3(cst_lst3)
        cst_lst3.heading("1", text="bicycle_id")
        cst_lst3.heading("2", text="bike_station")
        cst_lst3.heading("3", text="")
        cst_lst3.heading("4", text="")
        i = 0
        for indexs in table3.index:
            list3 = table3.loc[indexs].values
            tuple3 = tuple(list3)
            cst_lst3.insert("", i, text=i, values=tuple3)
            i += 1

    # Return
    def initial_details():
        detail_list = payAmount.show_order(order_number2)
        print(order_number2)
        str1 = "\n  order number:              " + str(detail_list[0] + "\n" +
                                                       "  start time:                   " + str(detail_list[1]) + "\n" +
                                                       "  end time:                    " + str(detail_list[2]) + "\n" +
                                                       "  period of use:             " + str(detail_list[3]) + "\n" +
                                                       "  bicycle id:                   " + str(detail_list[6]) + "\n" +
                                                       "  customer:                   " + str(detail_list[4]) + "\n" +
                                                       "  start bike station:       " + str(detail_list[7]) + "\n" +
                                                       "  end bike station:         " + str(detail_list[8]) + "\n")
        text_label["text"] = str1
        print(detail_list)

    def return_function(order_number2):
        new_location = postcode_listbox.get()
        location = new_location.split()
        new_region = location[3]
        print(new_region)
        new_bikestation = location[1]
        new_postcode = location[2] + location[3]
        payAmount.sel_bikestation(new_region, order_number2)
        payAmount.return_bike(order_number2)
        amount = payAmount.cal_amount(order_number2)
        calculateAmount_label["text"] = str(amount)
        initial_details()

    def pay_bill(order_number):
        if payAmount.pay_order(order_number):
            tkinter.messagebox.showinfo("bike_share_system", "Success")
            initial_details()
        else:
            tkinter.messagebox.showinfo("bike_share_system", "Insufficient balance")

    # report the broken bike which need to change the status of the bike
    def report():
        bike_id = cst_BikeIdText3.get()
        # update bike status
        cursor.execute('UPDATE bicycles SET broken_status="1" WHERE bicycles.bicycle_id=%s' % bike_id)
        conn.commit()

    # GUI

    window_customer = Tk()
    window_customer.title("Customer system")
    window_customer.geometry("600x800")

    # Rent
    cst_lab1 = Label(window_customer, text=" Rent ", background="light grey")
    cst_lab1.place(x=40, y=20)

    cst_lab2 = Label(window_customer, text="Region:")
    cst_lab2.place(x=40, y=40)

    cst_regiontext = Entry(window_customer, text="")
    cst_regiontext.place(x=120, y=40, width=150, height=25)
    cst_regiontext["justify"] = "left"
    cst_regiontext.focus()

    cst_btn1 = Button(window_customer, text="Search", command=search1)
    cst_btn1.place(x=315, y=40, width=100, height=25)

    cst_btn2 = Button(window_customer, text="Clear", command=clear)
    cst_btn2.place(x=440, y=40, width=100, height=25)

    cst_lab3 = Label(window_customer, text="Bike ID:")
    cst_lab3.place(x=40, y=70)

    cst_BikeIdText = Entry(window_customer, text="")
    cst_BikeIdText.place(x=120, y=70, width=150, height=25)
    cst_BikeIdText["justify"] = "left"
    cst_BikeIdText.focus()

    cst_btn3 = Button(window_customer, text="Rent", command=rent)
    cst_btn3.place(x=315, y=70, width=225, height=25)

    cst_lst1 = ttk.Treeview(window_customer, show="headings")
    cst_lst1["columns"] = ('1', '2', '3', '4')
    cst_lst1.column('1', width=100)  # 表示列,不显示
    cst_lst1.column('2', width=100)
    cst_lst1.column('3', width=100)
    cst_lst1.column('4', width=100)

    cst_lst1.place(x=40, y=100, width=500, height=150)

    # returnAndPay

    cst_lab4 = Label(window_customer, text="Return", background="light grey")
    cst_lab4.place(x=40, y=260)
    postcode_listbox = tk.StringVar(window_customer)
    postcode_listbox_chosen = ttk.Combobox(window_customer, width=20, textvariable=postcode_listbox)
    location_dic = payAmount.show_bike_station()
    print(location_dic)
    postcode_listbox_chosen['values'] = (location_dic)
    postcode_listbox_chosen.grid(column=1, row=2)
    postcode_listbox_chosen.current(0)
    postcode_listbox_chosen.place(x=150, y=290, width=380, height=25)

    bikeStation_label = tk.Label(window_customer, text="Bike station:")
    bikeStation_label.place(x=40, y=290)

    orderDetails_label = tk.Label(window_customer, text="Order Details:")
    orderDetails_label.place(x=40, y=320)

    amount_label = tk.Label(window_customer, text="Amount: ")
    amount_label.place(x=40, y=515)

    return_button = tk.Button(window_customer, text="Return", command=lambda: return_function(order_number2))
    return_button.place(x=40, y=540, width=225, height=25)

    pay_button = tk.Button(window_customer, text="Pay", command=lambda: pay_bill(order_number2))
    pay_button.place(x=315, y=540, width=225, height=25)

    calculateAmount_label = tk.Label(window_customer, text="")
    calculateAmount_label.place(x=100, y=515)

    text_label = tk.Label(window_customer, text="", borderwidth=2, justify="left", anchor="w", relief="groove")
    text_label.place(x=45, y=350, width=490, height=160)

    # Report
    cst_lab7 = Label(window_customer, text="Report", background="light grey")
    cst_lab7.place(x=40, y=575)

    cst_lab8 = Label(window_customer, text="Bike ID:")
    cst_lab8.place(x=40, y=605)

    cst_BikeIdText3 = Entry(window_customer, text="")
    cst_BikeIdText3.place(x=120, y=605, width=150, height=25)
    cst_BikeIdText3["justify"] = "left"
    cst_BikeIdText3.focus()

    cst_btn9 = Button(window_customer, text="Search", command=search3)
    cst_btn9.place(x=315, y=605, width=100, height=25)

    cst_btn10 = Button(window_customer, text="Report", command=report)
    cst_btn10.place(x=440, y=605, width=100, height=25)

    cst_lst3 = ttk.Treeview(window_customer, show="headings")
    cst_lst3["columns"] = ('1', '2', '3', '4')
    cst_lst3.column('1', width=100)
    cst_lst3.column('2', width=100)
    cst_lst3.column('3', width=100)
    cst_lst3.column('4', width=100)
    cst_lst3.place(x=40, y=635, width=500, height=130)

    window_customer.mainloop()
    conn.close()
